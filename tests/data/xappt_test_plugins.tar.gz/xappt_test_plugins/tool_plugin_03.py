import trigger_an_import_error

import xappt


@xappt.register_plugin
class ToolPlugin03(xappt.BaseTool):
    def execute(self, **kwargs) -> int:
        pass

