from typing import Optional

import xappt


@xappt.register_plugin
class InterfacePlugin02(xappt.BaseInterface):
    def invoke(self, plugin: xappt.BaseTool, **kwargs):
        pass

    def message(self, message: str):
        pass

    def warning(self, message: str):
        pass

    def error(self, message: str, *, details: Optional[str] = None):
        pass

    def ask(self, message: str) -> bool:
        pass

    def progress_start(self):
        pass

    def progress_update(self, message: str, percent_complete: float):
        pass

    def progress_end(self):
        pass
