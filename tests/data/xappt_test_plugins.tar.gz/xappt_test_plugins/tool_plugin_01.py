import xappt


@xappt.register_plugin
class ToolPlugin01(xappt.BaseTool):
    def execute(self, **kwargs) -> int:
        pass
