import xappt


@xappt.register_plugin
class ToolPlugin02(xappt.BaseTool):
    def execute(self, **kwargs) -> int:
        pass
